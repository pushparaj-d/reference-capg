package com.cg.capstore.exceptions;

@SuppressWarnings("serial")
public class CustomExceptions extends Exception {

	public CustomExceptions() {
		super();
	}
	public CustomExceptions(String message) {
		super(message);
	}
}
