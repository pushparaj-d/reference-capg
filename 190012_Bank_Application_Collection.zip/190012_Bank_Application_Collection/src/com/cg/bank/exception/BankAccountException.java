package com.cg.bank.exception;

@SuppressWarnings("serial")
public class BankAccountException extends Exception{

	public BankAccountException() {
		super();
	}
	public BankAccountException(String exception) {
		super(exception);
	}
	
}

