package com.cg.bank.ui;

import java.util.Collection;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Customer_Information;
import com.cg.bank.exception.BankAccountException;
import com.cg.bank.service.Account_Operation_Implementation;
import com.cg.bank.service.Account_operation;

public class Bank {
	static Scanner sc = new Scanner(System.in);

	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return sc.next();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer_Information customer = new Customer_Information();
		account.setAccountHolderName(input("Enter Account Holder Name"));
		System.out.println("Enter Initial amount:");
		double amount = sc.nextDouble();
		account.setOpeningBalance(amount);
		System.out.println("Enter age:");
		int age=sc.nextInt();
		customer.setAge(age);
		customer.setStreetName(input("Enter street name"));
		customer.setArea(input("Enter Area:"));
		customer.setState(input("Enter state"));
		System.out.println("Enter Zipcode");
		long zipCode=sc.nextLong();
		customer.setZipCode(zipCode);
		account.setCustomer(customer);
		return account;
	}

	public static void main(String[] args) {
		Account_operation accountService = new Account_Operation_Implementation(5);
		
		int choice = 0;
		int accountNo;
		double amount;
		Account account;
		do {
			System.out.println("Welcome to World Bank...");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.FundsTransfer");
			System.out.println("5.Show Balance");
			System.out.println("6.PrintTransactions");
			System.out.println("7.Exit");
			System.out.print("Enter Choice:");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Account Creation in process...");
				account = createCustomer();
				try {
					account = accountService.createAccount(account);
					
				} catch (BankAccountException e1) {
					e1.printStackTrace();
				}
				System.out.println(account);
				System.out.println("Account Created...");
				break;
			case 2:
				System.out.println("Account Deposit in process...");
				accountNo = Integer.parseInt(input("\nEnter Account No: "));
				amount = Double.parseDouble(input("\nEnter Amount: "));
				try {
					accountService.deposit(accountNo, amount);
				} catch (BankAccountException e) {
					System.err.println("Account Deposit:->"+e.getMessage());
				}
				System.out.println("Account Deposited...");
				break;
			case 3:
				System.out.println("Account Withdraw in process...");
				accountNo = Integer.parseInt(input("\nEnter Account No: "));
				amount = Double.parseDouble(input("\nEnter Amount: "));
				try {
					accountService.withdraw(accountNo, amount);
				} catch (BankAccountException e) {
					System.err.println("Account Withdraw:->"+e.getMessage());
				}
				System.out.println("Account Withdrawn...");
				break;
			case 4:
				System.out.println("Fundtransfer is in process.....");
				int sender=Integer.parseInt("\nEnter sender account number:");
				int receiver=Integer.parseInt("\nEnter receiver's account number:");
				amount=Double.parseDouble("\nEnter amount:");
				try {
					accountService.fundsTransfer(sender, receiver, amount);
				} catch (Exception e) {
					System.err.println("Fund Transfer:->"+e.getMessage());
				}
				break;
			case 5:
				System.out.println("Account Show Balance in process...");
				accountNo = Integer.parseInt(input("\nEnter Account No: "));
				try {
					account = accountService.getBalance(accountNo);
					System.out.println("Current Balance: " + account.getCurrentBalance());
					System.out.println("Account Balance Shown...");
				} catch (BankAccountException e) {
					e.printStackTrace();
				}
				break;
			case 6:
				System.out.println("Account Transaction in process...");
				Collection<Account> accounts = accountService.getTransactions();
				accounts.forEach(System.out::println);
				System.out.println("Account Transaction printed...");
				break;
			default:
				System.out.println("Exit...");
			}
		} while (choice != 7);
	}
}
