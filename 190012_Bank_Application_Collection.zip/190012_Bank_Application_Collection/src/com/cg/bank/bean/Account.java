package com.cg.bank.bean;
public class Account {

	static int ACCOUNT_NUMBER_SEQUENCE=0;
	private	int accountNo;
	private String accountHolderName;
	private double openingBalance; 
	private	double currentBalance;
	private Customer_Information customer;

	
	
	public Customer_Information getCustomer() {
		return customer;
	}
	public void setCustomer(Customer_Information customer) {
		this.customer = customer;
	}
	public Account() {
		super();
	}
	public Account(String accountHolderName, double openingBalance) {
		super();
		ACCOUNT_NUMBER_SEQUENCE++;
		setAccountNo(ACCOUNT_NUMBER_SEQUENCE);
		setAccountHolderName(accountHolderName);
		setOpeningBalance(openingBalance);
		setCurrentBalance(openingBalance);
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public double getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}
	
	
}
