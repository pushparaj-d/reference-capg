package com.cg.bank.bean;


public class Customer_Information {

	public String StreetName, Area, State;
	public int age;
	public long ZipCode;
	


	public Customer_Information() {
		super();
	}

	public String getStreetName() {
		return StreetName;
	}

	public void setStreetName(String streetName) {
		StreetName = streetName;
	}

	public String getArea() {
		return Area;
	}

	public void setArea(String area) {
		Area = area;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getZipCode() {
		return ZipCode;
	}

	public void setZipCode(long zipCode) {
		ZipCode = zipCode;
	}

	public Customer_Information(int accountNumber,String accountType, double initial_Balance, String name, String streetName, String area, String state, int age,
			long zipCode) {
		super();
		
		StreetName = streetName;
		Area = area;
		State = state;
		this.age = age;
		ZipCode = zipCode;
	}
}
