package com.cg.bank.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.BankAccountException;

public class Account_Operation_Implementation implements Account_operation {

Map<Integer, Account> map_Account;
	
	public Account_Operation_Implementation(int size) {
		map_Account = new HashMap<Integer, Account>(size);
	}
	HashMap<Integer, List<String>> tmap = new HashMap<Integer, List<String>>();

	@Override
	public Account createAccount(Account account) {
		System.out.println(account.getAccountNo());
		return map_Account.put(account.getAccountNo(), account);
		
	}

	@Override
	public void deposit(int accountNo, double amount) throws BankAccountException {
		Account account = map_Account.get(accountNo);
		if(account == null) throw new BankAccountException(accountNo+" does not exists...");
		double currentBalance = account.getCurrentBalance();
		currentBalance += amount;
		account.setCurrentBalance(currentBalance);
		map_Account.put(account.getAccountNo(), account);
	}

	@Override
	public void withdraw(int accountNo, double amount) throws BankAccountException {
		Account account = map_Account.get(accountNo);
		if(account == null) throw new BankAccountException(accountNo+" does not exists...");		
		double currentBalance = account.getCurrentBalance();
		currentBalance -= amount;
		account.setCurrentBalance(currentBalance);
	}
	
	@Override
	public Account getBalance(int accountNo) throws BankAccountException {
		if(!map_Account.containsKey(accountNo)) throw new BankAccountException(accountNo+" does not exists...");
		return map_Account.get(accountNo);
	}

	@Override
	public Collection<Account> getTransactions() {
		return map_Account.values();
	}

	@Override
	public void fundsTransfer(int fromAccount, int toAcctount, double amount) throws BankAccountException {
		double wamount = map_Account.get(fromAccount).getCurrentBalance();
		wamount -= amount;
		map_Account.get(fromAccount).setCurrentBalance(wamount);
		double damount = map_Account.get(toAcctount).getCurrentBalance();
		damount += amount;
		map_Account.get(toAcctount).setCurrentBalance(damount);
	}

	@Override
	public void transactioHistory(int accountnumber) throws BankAccountException {
		
	}

	@Override
	public void accountDetails() throws BankAccountException {
		System.out.println(map_Account);
	}


}
