package com.cg.bank.service;

import java.util.Collection;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.BankAccountException;

public interface Account_operation {

	public void withdraw(int accountNo, double amount) throws BankAccountException;
	public void deposit(int accountNo, double amount) throws BankAccountException;
	public void fundsTransfer(int fromAccount, int toAcctount, double amount) throws BankAccountException;
	public void transactioHistory(int accountnumber) throws BankAccountException;
	public void accountDetails() throws BankAccountException;
	public Account getBalance(int accountNo) throws BankAccountException;
	public Collection<Account> getTransactions();
	Account createAccount(Account account) throws BankAccountException;
}
