export interface Merchant {
    firstName: string;
    lastName: string;
    email: string;
    storeName: string;
    phone: string;
    password: string;
    isActive: boolean;
  }
