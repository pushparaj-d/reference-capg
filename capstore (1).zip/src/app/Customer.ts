export class Customer {
    firstName: string;
    lastName: string;
    email: string;
    phone: number;
    password: string;
    isActive: boolean;
}
