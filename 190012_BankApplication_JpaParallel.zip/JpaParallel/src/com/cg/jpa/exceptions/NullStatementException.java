package com.cg.jpa.exceptions;

public class NullStatementException {

}
