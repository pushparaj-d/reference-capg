package com.cg.jpa.exceptions;

public class InvalidQueryException {

}
