package com.cg.jpa.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="accno",initialValue=1,allocationSize=1)
public class Account {
	@Id
	@GeneratedValue(generator="accno",strategy=GenerationType.SEQUENCE)
	private int accno;
	private double initialbalance;
	private String accType;
	@OneToOne(cascade = CascadeType.ALL)
	private Customer customer;
	
	
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public double getInitialbalance() {
		return initialbalance;
	}
	public void setInitialbalance(double initialbalance) {
		this.initialbalance = initialbalance;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Account [accno=" + accno + ", initialbalance=" + initialbalance + ", accType=" + accType + ", customer="
				+ customer + "]";
	}
	
	
	
	

}
