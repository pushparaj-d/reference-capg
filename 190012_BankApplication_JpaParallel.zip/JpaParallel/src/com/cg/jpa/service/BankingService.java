package com.cg.jpa.service;

import javax.security.auth.login.AccountNotFoundException;

import com.cg.jpa.bean.Account;
import com.cg.jpa.exceptions.InsufficientBalanceException;

public interface BankingService {

	void createAccount(Account account);

	void deposit() throws InsufficientBalanceException, AccountNotFoundException;

	void withdraw() throws InsufficientBalanceException, AccountNotFoundException;
	
	void fundsTransfer() throws InsufficientBalanceException,AccountNotFoundException;
	
	void showAccount() throws AccountNotFoundException;

}
