package com.cg.jpa.ui;

import java.util.Scanner;

import javax.security.auth.login.AccountNotFoundException;

import com.cg.jpa.bean.Account;
import com.cg.jpa.bean.Customer;
import com.cg.jpa.exceptions.InsufficientBalanceException;
import com.cg.jpa.service.BankingServiceImpl;

public class Bank {
	static Scanner sc = new Scanner(System.in);

	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return sc.next();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer customer = new Customer();
		double amount = sc.nextDouble();
		account.setInitialbalance(amount);
		account.setAccType(input("Enter Account Type"));
		customer.setName(input("Enter Name"));
		customer.setMobile(input("Enter Mobile no"));
		customer.setCity(input("Enter city"));
		customer.setDno(input("Enter door no"));
		customer.setPincode(input("Enter pincode"));
		account.setCustomer(customer);
		return account;
	}

	public static void main(String[] args) {
		BankingServiceImpl impl = new BankingServiceImpl();
		int choice;
		do {
			System.out.println("WELCOME TO XYZ BANK");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			System.out.println("3 :with draw");
			System.out.println("4 :Funds Transfer");
			System.out.println("5 :Search account");
			System.out.println("Enter Choice: ");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Account creation is in process......");
				System.out.println("Enter Initial amount to deposit:");
				impl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				break;
			case 2:
				try {
					System.out.println("Deposit money  is in process......");
					impl.deposit();
					System.out.println("money is deposited......");
				} catch (AccountNotFoundException | InsufficientBalanceException e) {

				}
				break;

			case 3:
				try {
					System.out.println("Money withdraw is in process......");
					impl.withdraw();
					System.out.println("Money is withdrawn......");
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
				}
				break;
			case 4:
				try {
					System.out.println("Fund transfer is in process......");
					impl.fundsTransfer();
					System.out.println("Fund transfer is completed......");
				} catch (AccountNotFoundException | InsufficientBalanceException e) {
					e.printStackTrace();
				}
				break;
			case 5:
				try {
					impl.showAccount();
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		} while (choice<6);

	}

}
