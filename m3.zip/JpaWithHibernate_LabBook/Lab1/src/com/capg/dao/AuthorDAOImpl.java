package com.capg.dao;

import javax.persistence.EntityManager;

import com.capg.dbUtil.AuthorDB;
import com.capg.entities.AuthorDetails;

public class AuthorDAOImpl implements AuthorDAO {

	AuthorDB con;
	EntityManager em;
	public AuthorDAOImpl(){
		con=new AuthorDB();
		em= con.getManager();
	}
	@Override
	public void addAuthor(AuthorDetails a) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(a);
		em.flush();
		em.getTransaction().commit();
	}

	@Override
	public void removeAuthor(AuthorDetails a) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.remove(a);
		em.flush();
		em.getTransaction().commit();

	}

	@Override
	public void updateAuthor(AuthorDetails a) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.merge(a);
		em.flush();
		em.getTransaction().commit();

	}

	@Override
	public AuthorDetails findAuthor(int aid) {
		// TODO Auto-generated method stub
		return em.find(AuthorDetails.class, aid);
	}

}
