package com.cg.bank.service;

import com.cg.bank.exception.AccountMismatchException;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;
import com.cg.bean.Account;

public interface BankServices {

	void  createAccount(Account account);

	void deposit(double amount, Integer accno) throws AccountNotFoundException;

	void withDraw(double amount, Integer accno) throws AccountNotFoundException, InsufficientBalanceException;

	void fundTransfer(Integer accno1, Integer accno2) throws AccountNotFoundException, InsufficientBalanceException, AccountMismatchException;
}
