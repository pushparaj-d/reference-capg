package com.cg.bank.exception;

import java.util.Scanner;

@SuppressWarnings("serial")
public class AccountNotFoundException extends Exception{

	public AccountNotFoundException(Integer accno, String string) {
		super(accno+" "+string);
		Scanner sc=new Scanner(System.in);
		System.out.println(accno+" "+string);
		sc.nextLine();
		sc.close();
		
	}

}
