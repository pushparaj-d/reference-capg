package com.cg.bank.exception;

@SuppressWarnings("serial")
public class InsufficientBalanceException extends Exception
{

	public InsufficientBalanceException(Integer accno, String string) {
		super(accno+" "+string);
		System.out.println(accno+" "+string);
	}

}
