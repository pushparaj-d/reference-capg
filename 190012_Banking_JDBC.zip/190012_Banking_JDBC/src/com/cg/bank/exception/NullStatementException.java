package com.cg.bank.exception;

public class NullStatementException {

}
