package com.cg.bank.jdbc;

import java.sql.Date;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.service.Transaction;
import com.cg.bean.Account;


public interface BankingService1 {
	public void insert(Account account);

	public void update(double balance, Integer accno);

	public void delete(Integer accno) throws AccountNotFoundException;

	public void addTrans(Transaction transaction, Integer accno, Date date);

	public void query();

}
