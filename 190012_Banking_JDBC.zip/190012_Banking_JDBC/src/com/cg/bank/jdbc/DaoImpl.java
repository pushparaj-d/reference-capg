package com.cg.bank.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.service.Transaction;
import com.cg.bean.Account;

@SuppressWarnings("serial")
public class DaoImpl extends Throwable implements BankingService1 {
	static Scanner scan = new Scanner(System.in);

	@Override
	public void insert(Account account) {

		try {
			Connection conn = DatabaseConnectivity.getConnection();
			PreparedStatement stmt = conn.prepareStatement(
					"INSERT INTO Account (accno,accType,Name,city,doorno,phoneno,pincode,initialbalance)  VALUES (ACCNO.nextval,?,?,?,?,?,?,?)",
					new String[] { "ACCNO" });
			stmt.setString(1, account.getAccType());
			stmt.setString(2, account.getCustomer().getName());
			stmt.setString(3, account.getCustomer().getCity());
			stmt.setString(4, account.getCustomer().getDoorno());
			stmt.setString(5, account.getCustomer().getPhoneNo());
			stmt.setString(6, account.getCustomer().getPincode());
			stmt.setDouble(7, account.getInitialbalance());
			int i = stmt.executeUpdate();
			ResultSet set = stmt.getGeneratedKeys();
			set.next();
			account.setAccno((int) set.getLong(1));

			if (i > 0)
				System.out.println("executed");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void update(double balance, Integer accno) {

		String str = "update Account set initialbalance=" + balance + "where accno=" + accno;

		try {
			Connection conn = DatabaseConnectivity.getConnection();
			Statement st = conn.createStatement();

			int i = st.executeUpdate(str);
			if (i > 0)
				System.out.println("executed");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void delete(Integer accno) throws AccountNotFoundException {
		String s = "DELETE FROM Account WHERE accno=" + accno;

		try {
			Connection conn = DatabaseConnectivity.getConnection();
			Statement st = conn.createStatement();

			int i = st.executeUpdate(s);
			if (i > 0)
				System.out.println("row deleted");
			else {
				throw new AccountNotFoundException(accno, "Account not found");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void addTrans(Transaction transaction, Integer accno, Date date) {

		try {
			Connection conn = DatabaseConnectivity.getConnection();
			PreparedStatement stmt = conn.prepareStatement(
					"INSERT INTO TRANSACTIONS  VALUES (?,TRANS_ID.nextval,?,?,?)", new String[] { "TRANS_ID" });

			stmt.setInt(1, accno);
			// stmt.setInt(2, transaction.getTransId());
			stmt.setString(2, transaction.getDescription());
			stmt.setDouble(3, transaction.getAmount());
			stmt.setDate(4, date);
			int i = stmt.executeUpdate();
			ResultSet set = stmt.getGeneratedKeys();
			set.next();
			transaction.setTrans_Id((int) set.getLong(1));

			if (i > 0)
				System.out.println("executed");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void query() {
		String str = scan.nextLine();

		try {
			Connection conn = DatabaseConnectivity.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(str);

			ResultSetMetaData resultSetMetaData = rs.getMetaData();
			int count = resultSetMetaData.getColumnCount();
			if (count == 0) {
				System.err.println("deleted all rows");
			} else {
				while (rs.next()) {
					for (int i = 1; i <= count; i++) {
						System.out.print(rs.getString(i) + " ");
					}
					System.out.println();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public String query(String query) {
		String result = null;
		try {
			Connection conn = DatabaseConnectivity.getConnection();

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				result = rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

}
