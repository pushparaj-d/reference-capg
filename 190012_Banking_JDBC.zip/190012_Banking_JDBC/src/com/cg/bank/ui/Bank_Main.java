package com.cg.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.bank.exception.AccountMismatchException;
import com.cg.bank.exception.AccountNotFoundException;
import com.cg.bank.exception.InsufficientBalanceException;
import com.cg.bank.jdbc.DaoImpl;
import com.cg.bank.service.BankServicesImplementation;
import com.cg.bean.Account;
import com.cg.bean.Customer;

public class Bank_Main {
	static Scanner scan = new Scanner(System.in);

	private static String input(String string) {
		String message = string;
		System.out.println(message);
		return scan.nextLine();
	}

	private static Account createCustomer() {
		Account account = new Account();
		Customer customer = new Customer();
		customer = new Customer();
		scan.nextLine();
		customer.setName(input("enter name"));
		System.out.println("Enter Initial Balance");
		double amount=scan.nextDouble();
		account.setInitialbalance(amount);
		customer.setPhoneNo(input("enter phone number"));
		customer.setDoorno(input("enter door no"));
		customer.setPincode(input("enter pincode"));
		account.setAccType(input("enter type of account"));
		customer.setCity(input("enter city"));
		account.setCustomer(customer);

		return account;
	}

	public static void main(String[] args) {
		BankServicesImplementation impl = new BankServicesImplementation();
		
		DaoImpl daoImpl = new DaoImpl();
		int choice;
		do {
			System.out.println("welcome to Abc Bank");
			System.out.println("1 :Create Account");
			System.out.println("2 :Deposit");
			System.out.println("3 :Funds Transfer");
			System.out.println("4 :Withdraw");
			System.out.println("5: Delete");
			System.out.println("6 : Query");
			System.out.println("Enter Choice: ");
			choice = scan.nextInt();

			switch (choice) {
			case 1:
				impl.createAccount(createCustomer());
				System.out.println("Account created Successfully");
				break;
			case 2:
				try {
					System.out.println("enter amount to be deposit,enter account no");
					impl.deposit(scan.nextDouble(), scan.nextInt());

				} catch (AccountNotFoundException e) {
				} catch (NumberFormatException e) {
				} catch (InputMismatchException e) {
				}
				scan.nextLine();
				break;

			case 3:

				try {
					System.out.println("Enter sender accno and Receiver accNo");
					impl.fundTransfer(scan.nextInt(), scan.nextInt());

				} catch (InsufficientBalanceException e1) {

				} catch (AccountMismatchException e) {

				} catch (NumberFormatException e) {
				} catch (InputMismatchException e) {
				}

				break;
			case 4:
				try {
					System.out.println("Enter amount and account no to with draw");

					double amount = 0;
					Integer accno = null;
					amount = scan.nextDouble();
					accno = scan.nextInt();
					impl.withDraw(amount, accno);

				} catch (InsufficientBalanceException e) {

				} catch (AccountNotFoundException e) {

				} catch (NumberFormatException e) {
				} catch (InputMismatchException e) {
				}

				break;

			case 5:
				Integer accno = scan.nextInt();
				try {

					daoImpl.delete(accno);
					throw new AccountNotFoundException(accno, "Account not found");
				} catch (AccountNotFoundException e) {
				}
				break;
			case 6:

				daoImpl.query();

				break;

			default:
				System.err.println("invalid choice");
			}

		} while (choice<7);
	}
}
