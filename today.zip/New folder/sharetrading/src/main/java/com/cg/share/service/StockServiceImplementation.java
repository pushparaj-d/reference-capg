package com.cg.share.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.share.bean.Stock;
import com.cg.share.dao.StockRepository;
import com.cg.share.exception.StockException;

@Service
public class StockServiceImplementation implements StockService {

	@Autowired
	private StockRepository stockRepository;
	double stockBrokerage;

	// Creating the stock
	// If the Stock already exists it throws Exception
	// The total price and brokerage are calculated and added to table
	@Override
	public List<Stock> createStock(Stock stock) throws StockException {
		if (stockRepository.existsById(stock.getId())) {
			throw new StockException("Stock with id=" + stock.getId() + " is already exists.");
		} else {
			double amount = stock.getPrice() * stock.getQuantity();
			if (stock.getQuantity() > 100) {
				stockBrokerage = ((0.3) / 100) * amount;
			} else {
				stockBrokerage = ((0.5) / 100) * amount;
			}
			stock.setAmount(amount);
			stock.setBrokerage(stockBrokerage);

		}
		stockRepository.save(stock);
		return viewAllStock();
	}

	// Updating the Stock by using the ID of the Stock
	// If the Stock is not available it will throw the exception with message which is handled by exception handler
	@Override
	public List<Stock> updateStock(Stock stock) throws StockException {
		if (!stockRepository.existsById(stock.getId())) {
			throw new StockException("Stock with id=" + stock.getId() + " doesn't exists.");
		} else {
			double amount = stock.getPrice() * stock.getQuantity();
			if (stock.getQuantity() > 100) {
				stockBrokerage = ((0.3) / 100) * amount;
			} else {
				stockBrokerage = ((0.5) / 100) * amount;
			}
			stock.setAmount(amount);
			stock.setBrokerage(stockBrokerage);
			stockRepository.save(stock);
			return viewAllStock();
		}
	}

	// Delete the stock using Id.
	@Override
	public List<Stock> deleteStock(int id) throws StockException {
		if (!stockRepository.existsById(id)) {
			throw new StockException("Stock with id " + id + " doesn't exist");
		}
		stockRepository.deleteById(id);
		return viewAllStock();
	}

	// Display all stocks available
	@Override
	public List<Stock> viewAllStock() throws StockException {
		try {
			return stockRepository.findAll();
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}

	@Override
	public Stock findStockById(int id) throws StockException {
		return stockRepository.findById(id).get();
	}

}
