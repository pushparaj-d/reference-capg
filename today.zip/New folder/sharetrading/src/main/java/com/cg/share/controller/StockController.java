package com.cg.share.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.share.bean.Stock;
import com.cg.share.exception.StockException;
import com.cg.share.service.StockService;

@RestController
public class StockController {

	@Autowired
	private StockService stockService;

	//mapping to create stock
	@PostMapping("/createstock")
	public List<Stock> createStock(@Valid @RequestBody Stock stock) throws StockException {
		return stockService.createStock(stock);
	}

	// mapping to update Stock
	@PutMapping("/stock/update")
	public List<Stock> updateStock(@Valid @RequestBody Stock stock) throws StockException {
		return stockService.updateStock(stock);
	}

	// Mapping to delete stock using id.
	@DeleteMapping("/stock/delete/{id}")
	public List<Stock> deleteStock(@PathVariable int id) throws StockException {
		return stockService.deleteStock(id);
	}

	// Mapping to view all stocks
	@RequestMapping("/stocks")
	public List<Stock> viewAllStock() throws StockException {
		return stockService.viewAllStock();
	}

	// Mapping to view a single Stock
	@GetMapping("/stock/{id}")
	public Stock findStockById(@PathVariable int id) throws StockException {
		return stockService.findStockById(id);
	}
}
