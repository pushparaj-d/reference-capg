package com.cg.share.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.share.bean.Stock;
import com.cg.share.exception.StockException;

// list of Services of stock trading
@Repository
public interface StockService {

	List<Stock> createStock(Stock stock) throws StockException;
	List<Stock> updateStock(Stock stock) throws StockException;
	List<Stock> deleteStock(int id) throws StockException;
	List<Stock> viewAllStock() throws StockException;
	Stock findStockById(int id) throws StockException;
	
}
