package com.cg.share.exception;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalErrorHandler {
@ExceptionHandler({StockException.class})
public ResponseEntity<String>errorHandler(Exception exception){
	return new ResponseEntity<String>(exception.getMessage(),HttpStatus.CONFLICT);
}

@ExceptionHandler({MethodArgumentNotValidException.class})
public ResponseEntity<String>aruguementHandlers(MethodArgumentNotValidException exception){
	String message="";
	List<FieldError> errors=exception.getBindingResult().getFieldErrors();
	for (FieldError fieldError : errors) {
		message+=fieldError.getDefaultMessage();
	}
	return new ResponseEntity<String>(message,HttpStatus.CONFLICT);
}
}
